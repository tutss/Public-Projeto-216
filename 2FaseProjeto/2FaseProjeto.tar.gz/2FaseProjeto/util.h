#ifndef UTIL_H
#define UTIL_H
typedef enum {
  false,
  true
} Boolean;
#endif
