#ifndef ARENA_H
#define ARENA_H
typedef struct {
  int terreno;
  int vazia;
  int nCristais;
  int base;
} Celula;
//int main ();
//void assignRobo(Maquina *m);
#endif
